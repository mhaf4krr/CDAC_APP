const express = require("express")

let fs = require("fs")

const app = express()

const cors = require("cors")

app.use(cors())

let multer = require("multer")
multer = multer({  limits: { fieldSize: 25 * 1024 * 1024 }})

app.get("/",(req,res)=>{
    console.log("Received")
    res.send("Hello")
})

app.post("/new",multer.none(),async(req,res)=>{
    
    try {
        let data = req.body
        
        console.log(data)
       
        fs.writeFile(__dirname+`/public/uploads/${data["photo_label"]}.jpg`,data["photo"],'base64',(err)=>{
            if(!err){
                console.log("Uploaded Picture")
                res.send("Done")
            }
        })
       
       

    } catch (error) {
        console.log(error)
        res.send(error.message)
    }

})




app.listen(3000)
